function inWords(number){ 	//alert(number);
	var rVal=number;
	rVal=Math.floor(rVal);
	var rup=new String(rVal);
	rupRev=rup.split("");
	actualNumber=rupRev.reverse();
	if(Number(rVal) >=0){}
   	else{
		alert('Number cannot be converted');
		return false;
	}
	if(Number(rVal)==0){
		document.getElementById('rupees').value=rup+''+'Rupees Zero';
		return false;
	}
	if(actualNumber.length>9){
		alert('The Number is too big to covertes');
		return false;
	}

	var numWords=["Zero", " One", " Two", " Three", " Four", " Five", " Six", " Seven", " Eight", " Nine"];
	var numPlace=['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', ' Nineteen'];
	var tPlace=['dummy', ' Ten', ' Twenty', ' Thirty', ' Forty', ' Fifty', ' Sixty', ' Seventy', ' Eighty', ' Ninety' ];

	var numWordsLength=rupRev.length;
	var totalWords="";
	var numtoWords=new Array();
	var finalWord="";
	j=0;
	for(i=0; i<numWordsLength; i++){
  		switch(i){
        	case 0:
           		if(actualNumber[i]==0 || actualNumber[i+1]==1 ) {
              		numtoWords[j]='';
          		} else {
                        numtoWords[j]=numWords[actualNumber[i]];
            	}
                numtoWords[j]=numtoWords[j]+'';
                break;
  			case 1:
            	CTen();
            	break;
        	case 2:
         		if(actualNumber[i]==0) {
                	numtoWords[j]='';
              	} else if(actualNumber[i-1]!=0 && actualNumber[i-2]!=0) {
                	numtoWords[j]=numWords[actualNumber[i]]+' Hundred and ';
                } else {
                        numtoWords[j]=numWords[actualNumber[i]]+' Hundred';
                }
               	break;
      		case 3:
            	if(actualNumber[i]==0 || actualNumber[i+1]==1) {
                	numtoWords[j]='';
              	} else {
               		numtoWords[j]=numWords[actualNumber[i]];
              	}
           		if(actualNumber[i+1] != 0 || actualNumber[i] > 0){
                	numtoWords[j]=numtoWords[j]+" Thousand";
               	}
               	break;
        	case 4:
            	CTen();
            	break;
          	case 5:
            	if(actualNumber[i]==0 || actualNumber[i+1]==1) {
                	numtoWords[j]='';
             	} else {
                	numtoWords[j]=numWords[actualNumber[i]];
               	}
              	if(actualNumber[i+1] != 0 || actualNumber[i] > 0){
            		numtoWords[j]=numtoWords[j]+" Lakh";
               	}
              	break;
   			case 6:
            	CTen();
             	break;
         	case 7:
          		if(actualNumber[i]==0 || actualNumber[i+1]==1 ){
              		numtoWords[j]='';
             	} else {
               		numtoWords[j]=numWords[actualNumber[i]];
               	}
              	numtoWords[j]=numtoWords[j]+" Crore";
             	break;
     		case 8:
            	CTen();
          		break;      
          	default:
            	break;
		}	//End of Switch case
		j++;
	}	//End of for loop

	function CTen(){
		if(actualNumber[i]==0) {
			numtoWords[j]='';
		} else if(actualNumber[i]==1) {
			numtoWords[j]=numPlace[actualNumber[i-1]];
		} else {
			numtoWords[j]=tPlace[actualNumber[i]];
		}
	}
	numtoWords.reverse();
	for(i=0; i<numtoWords.length; i++) {
		finalWord+=numtoWords[i];
	}
	document.getElementById("in_word").innerHTML=finalWord;
}	//End of the Function
